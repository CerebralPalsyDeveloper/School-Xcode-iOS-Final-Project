//
//  Package2MapVC.swift
//  Vacation Packages
//
//  Created by Jaret Smith on 11/10/23.
//

import UIKit
import MapKit
import CoreLocation


class Package2MapVC: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        let toronto = MKPointAnnotation()
        toronto.coordinate = CLLocationCoordinate2DMake(43.651070, -79.347015)
        toronto.title = "Hello, Toronto"
        
        let ent1 = MKPointAnnotation()
        ent1.coordinate = CLLocationCoordinate2DMake(43.642567, -79.387054)
        ent1.title = "CN Tower"
        
        let ent2 = MKPointAnnotation()
        ent2.coordinate = CLLocationCoordinate2DMake(43.623409, -79.368683)
        ent2.title = "Toronto Islands"
        
        let ent3 = MKPointAnnotation()
        ent3.coordinate = CLLocationCoordinate2DMake(43.645485, -79.464752)
        ent3.title = "High Gardens"
        
        let acc1 = MKPointAnnotation()
        acc1.coordinate = CLLocationCoordinate2DMake(43.715751,-79.601749)
        acc1.title = "Great Canadian Casino Resort Toronto"
        
        let acc2 = MKPointAnnotation()
        acc2.coordinate = CLLocationCoordinate2DMake(43.633251,-79.397087)
        acc2.title = "Toronto Marriott City Centre Hotel"
        
        let acc3 = MKPointAnnotation()
        acc3.coordinate = CLLocationCoordinate2DMake(43.651420,-79.513160)
        acc3.title = "Fairmont Royal York"
        
        mapLocation.addAnnotations([toronto,ent1, ent2, ent3, acc1, acc2, acc3])
        
        let region = MKCoordinateRegion(center: toronto.coordinate, latitudinalMeters: 10000, longitudinalMeters: 10000)
        
        mapLocation.setRegion(region, animated: true)
    }

    @IBOutlet weak var mapLocation: MKMapView!
 
}
