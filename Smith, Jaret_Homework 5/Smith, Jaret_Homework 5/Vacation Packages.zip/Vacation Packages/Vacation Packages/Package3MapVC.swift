//
//  Package3MapVC.swift
//  Vacation Packages
//
//  Created by Jaret Smith on 11/10/23.
//

import UIKit
import MapKit
import CoreLocation

class Package3MapVC: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        let barcelona = MKPointAnnotation()
        barcelona.coordinate = CLLocationCoordinate2DMake(41.3874, 2.1686)
        barcelona.title = "Hola, Barcelona"
        
        let ent1 = MKPointAnnotation()
        ent1.coordinate = CLLocationCoordinate2DMake(41.403706, 2.173504)
        ent1.title = "La Sagrada Familia"
        
        let ent2 = MKPointAnnotation()
        ent2.coordinate = CLLocationCoordinate2DMake(41.414494, 2.152695)
        ent2.title = "Park Guell"
        
        let ent3 = MKPointAnnotation()
        ent3.coordinate = CLLocationCoordinate2DMake(41.595776, 1.829814)
        ent3.title = "Montserrat Abbey and Mountain"
        
        let acc1 = MKPointAnnotation()
        acc1.coordinate = CLLocationCoordinate2DMake(41.383611,2.171111)
        acc1.title = "Hotel 1898"
        
        let acc2 = MKPointAnnotation()
        acc2.coordinate = CLLocationCoordinate2DMake(41.386913,2.196929)
        acc2.title = "Hotel Arts Barcelona"
        
        let acc3 = MKPointAnnotation()
        acc3.coordinate = CLLocationCoordinate2DMake(41.3909,2.1658)
        acc3.title = "Safestay Barcelona Passeig De Gracia"
        
        mapLocation.addAnnotations([barcelona,ent1, ent2, ent3, acc1, acc2, acc3])
        
        let region = MKCoordinateRegion(center: barcelona.coordinate, latitudinalMeters: 10000, longitudinalMeters: 10000)
        
        mapLocation.setRegion(region, animated: true)
    }

    @IBOutlet weak var mapLocation: MKMapView!
    
}
