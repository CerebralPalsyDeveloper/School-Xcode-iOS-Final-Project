//
//  Package1ReviewsVC.swift
//  Vacation Packages
//
//  Created by Jaret Smith on 11/9/23.
//

import UIKit
import CoreData

var items : [String] = []
var reviews: [Reviews] = []

class Package1ReviewsVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "Cell")
        
        var content = cell.defaultContentConfiguration()
        content.text = items[indexPath.row]
        cell.contentConfiguration = content
        
        //cell.textLabel?.text = items[indexPath.row]
        
        return cell
    }
    

    @IBOutlet weak var tblReviews: UITableView!
    
    override func viewDidLoad()
    {
            super.viewDidLoad()
            fetchReviews()
    }
    
    func fetchReviews() {
            items = []
            
            if let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext {
                do {
                    let fetchRequest: NSFetchRequest<Reviews> = Reviews.fetchRequest()
                    let reviews = try context.fetch(fetchRequest)
                    
                    for review in reviews {
                        if let reviewText = review.reviewTxt {
                            items.append(reviewText)
                        }
                    }
                    
                    tblReviews.reloadData()
                } catch {
                    //print("Error fetching reviews: \(error)")
                }
            }
        }
    /*override func viewDidAppear(_ animated: Bool) {
        items = []
                var data = [Reviews]()
                
                do
                {
                    data = try context.fetch(Reviews.fetchRequest())
                    
                    
                    for existingTask in data {
                                if let review = existingTask.reviewTxt, existingTask.username == activeUser {
                                    items.append(review)
                                }
                            }
                            
                            tblReviews.reloadData()
                }
                catch {}
                //tblItems.reloadData()
    }
     */
    
}
