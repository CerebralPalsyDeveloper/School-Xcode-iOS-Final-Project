//
//  Package2ReviewsVC.swift
//  Vacation Packages
//
//  Created by Jaret Smith on 11/10/23.
//

import UIKit
import CoreData

var items2 : [String] = []
var reviews2: [Reviews] = []

class Package2ReviewsVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items2.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "Cell")
        
        var content = cell.defaultContentConfiguration()
        content.text = items2[indexPath.row]
        cell.contentConfiguration = content
        
        //cell.textLabel?.text = items[indexPath.row]
        
        return cell
    }
    
    
    @IBOutlet weak var tblReviews: UITableView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        fetchReviews()
    }
    
    func fetchReviews() {
        items2 = []
        
        if let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext {
            do {
                let fetchRequest: NSFetchRequest<Reviews> = Reviews.fetchRequest()
                let reviews2 = try context.fetch(fetchRequest)
                
                for review in reviews2 {
                    if let review2Text = review.review2Txt {
                        items2.append(review2Text)
                    }
                }
                
                tblReviews.reloadData()
            } catch {
                //print("Error fetching reviews: \(error)")
            }
        }
    }
}
    
    


