//
//  Package3ReviewsVC.swift
//  Vacation Packages
//
//  Created by Turing on 11/10/23.
//

import UIKit
import CoreData

var items3 : [String] = []
var reviews3: [Reviews] = []

class Package3ReviewsVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items3.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "Cell")
        
        var content = cell.defaultContentConfiguration()
        content.text = items3[indexPath.row]
        cell.contentConfiguration = content
        
        //cell.textLabel?.text = items[indexPath.row]
        
        return cell
    }
    @IBOutlet weak var tblReviews: UITableView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        fetchReviews()
    }
    
    func fetchReviews() {
        items3 = []
        
        if let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext {
            do {
                let fetchRequest: NSFetchRequest<Reviews> = Reviews.fetchRequest()
                let reviews3 = try context.fetch(fetchRequest)
                
                for review in reviews3 {
                    if let review3Text = review.review3Txt {
                        items3.append(review3Text)
                    }
                }
                
                tblReviews.reloadData()
            } catch {
                //print("Error fetching reviews: \(error)")
            }
        }
    }
}
