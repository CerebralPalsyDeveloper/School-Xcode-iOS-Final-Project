//
//  PackagesTableViewCell.swift
//  Vacation Packages
//
//  Created by Jaret Smith on 11/8/23.
//

import UIKit

class PackagesTableViewCell: UITableViewCell {
    
    @IBOutlet weak var packageLabel: UILabel!
    
    @IBOutlet weak var packageImg: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
