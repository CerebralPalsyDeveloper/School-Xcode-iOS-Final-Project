//
//  writeReview.swift
//  Vacation Packages
//
//  Created by Jaret Smith on 11/9/23.
//

import UIKit

class writeReview: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var tvReview: UITextView!
    
    @IBOutlet weak var btnSaveReview: UIButton!
    
    @IBAction func btnSave(_ sender: Any)
    {
        let newReview = Reviews(context: context)
        newReview.username = activeUser
        
           if let reviewTxt = tvReview.text, !reviewTxt.isEmpty
        {
            newReview.reviewTxt = reviewTxt
            
            appDelegate.saveContext()
            
            tvReview.text = ""
               
        }
        else
        {
            // Show an alert if any fields are empty
            showAlert(title: "Missing Information", message: "Please fill in a review.")
        }
        
        func showAlert(title: String, message: String) {
            let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(okAction)
            present(alertController, animated: true, completion: nil)
        }
        
    }
    
}
