//
//  Package1MapVC.swift
//  Vacation Packages
//
//  Created by Jaret Smith on 11/8/23.
//

import UIKit
import MapKit
import CoreLocation

class Package1MapVC: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        let tahiti = MKPointAnnotation()
        tahiti.coordinate = CLLocationCoordinate2DMake(-17.6333308, -149.4499982)
        tahiti.title = "Salut, Tahiti"
        
        let ent1 = MKPointAnnotation()
        ent1.coordinate = CLLocationCoordinate2DMake(-17.7842912017,-149.303753908)
        ent1.title = "La Plage de Maui"
        
        let ent2 = MKPointAnnotation()
        ent2.coordinate = CLLocationCoordinate2DMake(-17.5352,-149.40159)
        ent2.title = "Faarumai Waterfalls"
        
        let ent3 = MKPointAnnotation()
        ent3.coordinate = CLLocationCoordinate2DMake(-17.5429,-149.5754)
        ent3.title = "Pa'ofa'i Gardens"
        
        let acc1 = MKPointAnnotation()
        acc1.coordinate = CLLocationCoordinate2DMake(-17.53502,-149.5696)
        acc1.title = "InterContinental Resort Tahiti"
        
        let acc2 = MKPointAnnotation()
        acc2.coordinate = CLLocationCoordinate2DMake(-17.538019,-149.567352)
        acc2.title = "Mahana Lodge Hostel"
        
        let acc3 = MKPointAnnotation()
        acc3.coordinate = CLLocationCoordinate2DMake(-17.5383683995,-149.563065025)
        acc3.title = "Tea Lodge"
        
        mapLocation.addAnnotations([tahiti,ent1, ent2, ent3, acc1, acc2, acc3])
        
        let region = MKCoordinateRegion(center: tahiti.coordinate, latitudinalMeters: 10000, longitudinalMeters: 10000)
        
        mapLocation.setRegion(region, animated: true)
    }

    @IBOutlet weak var mapLocation: MKMapView!
}
