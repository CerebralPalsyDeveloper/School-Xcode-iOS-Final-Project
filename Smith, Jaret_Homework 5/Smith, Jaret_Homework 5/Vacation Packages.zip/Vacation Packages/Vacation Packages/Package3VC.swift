//
//  Package3VC.swift
//  Vacation Packages
//
//  Created by Jaret Smith on 11/10/23.
//

import UIKit

class Package3VC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnFlightInfo(_ sender: Any)
    {
        if let url = URL(string: "https://www.expedia.com/Flights-Search?leg1=from%3AAustin%2C%20TX%20%28AUS-Austin-Bergstrom%20Intl.%29%2Cto%3ABarcelona%20%28BCN%20-%20Barcelona%20Intl.%29%2Cdeparture%3A12%2F15%2F2023TANYT&leg2=from%3ABarcelona%20%28BCN%20-%20Barcelona%20Intl.%29%2Cto%3AAustin%2C%20TX%20%28AUS-Austin-Bergstrom%20Intl.%29%2Cdeparture%3A12%2F29%2F2023TANYT&mode=search&options=carrier%3A%2Ccabinclass%3A%2Cmaxhops%3A1%2Cnopenalty%3AN&pageId=0&passengers=adults%3A1%2Cchildren%3A0%2Cinfantinlap%3AN&trip=roundtrip")
        {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
 
}
