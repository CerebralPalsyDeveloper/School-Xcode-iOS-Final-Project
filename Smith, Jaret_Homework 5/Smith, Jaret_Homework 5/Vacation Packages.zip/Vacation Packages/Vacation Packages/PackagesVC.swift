//
//  PackagesVC.swift
//  Vacation Packages
//
//  Created by Jaret Smith on 11/8/23.
//

import UIKit

class PackagesVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    let myPackages = ["Tahiti", "Toronto", "Barcelona"]
    let myPackagesImg = [UIImage(named: "tahiti"), UIImage(named: "toronto"), UIImage(named: "barcelona")]
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return myPackages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PackagesTableViewCell", for: indexPath) as! PackagesTableViewCell
        
        cell.packageLabel.text = myPackages[indexPath.row]
        cell.packageImg.image = myPackagesImg[indexPath.row]
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedPackage = myPackages[indexPath.row]
        performSegue(for: selectedPackage)
    }

    func performSegue(for package: String) {
        switch package {
        case "Tahiti":
            performSegue(withIdentifier: "TahitiSegue", sender: nil)
        case "Toronto":
            performSegue(withIdentifier: "TorontoSegue", sender: nil)
        case "Barcelona":
            performSegue(withIdentifier: "BarcelonaSegue", sender: nil)
        default:
            break
        }
    }

    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let nib = UINib(nibName: "PackagesTableViewCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "PackagesTableViewCell")
        tableView.delegate = self
        tableView.dataSource = self
    }

    @IBAction func btnSignOut(_ sender: Any)
    {
        activeUser = nil
    }
}
