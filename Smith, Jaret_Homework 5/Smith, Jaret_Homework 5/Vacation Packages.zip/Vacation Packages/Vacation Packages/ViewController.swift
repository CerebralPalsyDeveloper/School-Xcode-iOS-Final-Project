//
//  ViewController.swift
//  Vacation Packages
//
//  Created by Jaret Smith on 11/7/23.
//

import UIKit
import CoreData

let appDelegate = UIApplication.shared.delegate as! AppDelegate
let context = appDelegate.persistentContainer.viewContext

var activeUser : String?


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var txtUsername: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    func addNewAccount (newAccountUsername : String, newAccountPassword : String)
        {
            let newAccount = Accounts(context: context)
            
            appDelegate.saveContext()
            
            newAccount.username = newAccountUsername
            newAccount.password = newAccountPassword
        }
    
    @IBAction func btnRegisterUser(_ sender: Any) {
        let newUsername = txtUsername.text
            let newPassword = txtPassword.text

            if let username = newUsername, let password = newPassword {
                // Check if the username already exists
                if usernameExists(username: username) {
                    // Username already exists, show an alert
                    showAlert(title: "Username Exists", message: "The username is already in use. Please choose a different username.")
                } else {
                    // Username is unique, proceed to create and save the new account
                    addNewAccount(newAccountUsername: username, newAccountPassword: password)
                    showAlert(title: "Registration Successful", message: "The registration is successful")
                }
            }
        
    }
    func showAlert(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
    func usernameExists(username: String?) -> Bool {
        if let username = username {
            let fetchRequest: NSFetchRequest<Accounts> = Accounts.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "username == %@", username)

            do {
                let existingAccounts = try context.fetch(fetchRequest)
                return !existingAccounts.isEmpty
            } catch {
                //print("Error checking username existence: \(error.localizedDescription)")
                return false
            }
        }
        return false
    }
    @IBAction func btnSignIn(_ sender: Any)
    {
        var data = [Accounts]()
            
            do {
                data = try context.fetch(Accounts.fetchRequest())
                
                for existingAccount in data {
                    if existingAccount.username == txtUsername.text && existingAccount.password == txtPassword.text {
                        // Sign-in successful, show an alert, set the active user, and navigate to the main view
                        activeUser = txtUsername.text
                        //showAlert(title: "Success", message: "Sign in successful.")
                        
                        // Perform the segue to "navigationVC"
                        performSegue(withIdentifier: "toPackagesVC", sender: nil)
                        return
                    }
                }
                
                // If no match was found, show an alert for sign-in failure
                showAlert(title: "Error", message: "Invalid username or password. Please try again.")
            } catch {
                // Handle fetch request errors
                //print("Error during sign-in: \(error.localizedDescription)")
            }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        items = []
        items2 = []
        items3 = []
        var data = [Reviews]()
        
        do
        {
            data = try context.fetch(Reviews.fetchRequest())
            
            for existingReview in data
            {
                if existingReview.username == activeUser
                {
                    if let reviewTxt = existingReview.reviewTxt
                    {
                        items.append(reviewTxt)
                    }
                    if let review2Txt = existingReview.review2Txt
                    {
                        items2.append(review2Txt)
                    }
                    if let review3Txt = existingReview.review3Txt
                    {
                        items3.append(review3Txt)
                    }
                }
            }
        }
        catch {}
    }


}

