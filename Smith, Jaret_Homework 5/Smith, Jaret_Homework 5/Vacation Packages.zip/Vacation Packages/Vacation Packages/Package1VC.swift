//
//  Package1VC.swift
//  Vacation Packages
//
//  Created by Jaret Smith on 11/8/23.
//

import UIKit

class Package1VC: ViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnFlightInfo(_ sender: Any)
    {
        if let url = URL(string: "https://www.expedia.com/Flights-Search?flight-type=on&mode=search&trip=roundtrip&leg1=from:Austin,%20TX,%20United%20States%20of%20America%20(AUS-Austin-Bergstrom%20Intl.),to:Papeete,%20French%20Polynesia%20(PPT-Tahiti%20Faaa%20Intl.),departure:12/15/2023TANYT&leg2=from:Papeete,%20French%20Polynesia%20(PPT-Tahiti%20Faaa%20Intl.),to:Austin,%20TX,%20United%20States%20of%20America%20(AUS-Austin-Bergstrom%20Intl.),departure:12/29/2023TANYT&options=cabinclass:economy&fromDate=12/15/2023&toDate=12/29/2023&d1=2023-12-15&d2=2023-12-29&passengers=adults:1,infantinlap:N")
        {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
    
}
