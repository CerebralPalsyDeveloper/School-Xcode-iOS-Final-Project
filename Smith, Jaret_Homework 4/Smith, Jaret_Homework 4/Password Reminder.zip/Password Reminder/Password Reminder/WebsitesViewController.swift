//
//  WebsitesViewController.swift
//  Password Reminder
//
//  Created by Jaret Smith on 10/28/23.
//

import UIKit
import CoreData

var items : [String] = []
var websites: [Websites] = [] //should only have data for selected user
var selectedWebsite: Websites?

class WebsitesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    /*
     //from yesterday
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tblItems.dataSource = self
        tblItems.delegate = self
    }
     */
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        websites.removeAll()

        // Fetch and populate the 'websites' array
        if let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext {
            do {
                let fetchRequest: NSFetchRequest<Websites> = Websites.fetchRequest()
                let allWebsites = try context.fetch(fetchRequest)
                
                if allWebsites.count > 0
                {
                    for i in 0...(allWebsites.count - 1)
                    {
                        if activeUser == allWebsites[i].username
                        {
                            websites.append(allWebsites[i])
                        }
                        //print("websites array count: \(websites.count)")
                    }
                }
                
                
                
            } catch {
                // Handle fetch errors
                //print("Error fetching data: \(error)")
            }
        }

    }

    @IBOutlet weak var tblItems: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return items.count
        }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "Cell")
        
        var content = cell.defaultContentConfiguration()
        content.text = items[indexPath.row]
        cell.contentConfiguration = content
        
        //cell.textLabel?.text = items[indexPath.row]
        
        return cell
    }
    
    //delete items
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Remove the corresponding data from Core Data
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            
            do {
                let data = try context.fetch(Websites.fetchRequest()) as! [Websites]
                let website = data[indexPath.row]
                context.delete(website)
                try context.save()
            } catch {
                //print("Error deleting website: \(error.localizedDescription)")
            }
            
            // Remove the item from your data source
            items.remove(at: indexPath.row)
            
            // Update the table view to reflect the changes
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }

    
    override func viewDidAppear(_ animated: Bool) {
        items = []
                var data = [Websites]()
        
                do
                {
                    data = try context.fetch(Websites.fetchRequest())
                    
                    /*for existingTask in data
                    {
                        if existingTask.username == activeUser
                        {
                            items.append(existingTask.websiteName!)
                        }
                    } */
                    
                    for existingTask in data {
                                if let websiteName = existingTask.websiteName, existingTask.username == activeUser {
                                    items.append(websiteName)
                                }
                            }
                            
                            tblItems.reloadData()
                }
                catch {}
                //tblItems.reloadData()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("websites array count: \(websites.count)")
        print("indexPath.row: \(indexPath.row)")
        print("Active User: \(String(describing: activeUser))")
        
        if indexPath.row < websites.count {
            selectedWebsite = websites[indexPath.row]
            performSegue(withIdentifier: "toInformationVC", sender: nil)
        } else {
            //print("Index out of bounds")
        }
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toInformationVC" {
            if let informationVC = segue.destination as? InformationViewController {
                informationVC.selectedWebsite = selectedWebsite
            }
        }
    }
    @IBAction func btnSignOut(_ sender: Any)
    {
        activeUser = nil
            
            // Navigate back to the login screen
            performSegue(withIdentifier: "toLoginVC", sender: nil)
        
    }
    
}
