//
//  InformationViewController.swift
//  Password Reminder
//
//  Created by Jaret Smith on 10/28/23.
//
import UIKit
import CoreData

class InformationViewController: UIViewController
{
    // Declare your properties
    
    var data = [Websites]()
    
    var selectedWebsite: Websites?
    
    @IBOutlet weak var websiteNameLabel: UITextField!
    
    @IBOutlet weak var websiteURLLabel: UITextView!
    
    @IBOutlet weak var websiteUsernameLabel: UITextField!
    
    @IBOutlet weak var websitePasswordLabel: UITextField!
    
    var websites: [Websites] = []
    //var selectedWebsite: Websites?
    //var selectedWebsiteName: String?
    //var selectedIndex: Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        websiteURLLabel.dataDetectorTypes = .link
        
        
        if let selectedWebsite = selectedWebsite {
                    websiteNameLabel.text = selectedWebsite.websiteName
                    websiteURLLabel.text = selectedWebsite.websiteURL
                    websiteUsernameLabel.text = selectedWebsite.websiteUsername
                    websitePasswordLabel.text = selectedWebsite.websitePassword
                }
        if let selectedWebsite = selectedWebsite {
                    selectedWebsite.username = activeUser
                }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let website = selectedWebsite {
            // Display data from the selected website
            websiteNameLabel.text = website.websiteName
            websiteURLLabel.text = website.websiteURL
            websiteUsernameLabel.text = website.websiteUsername
            websitePasswordLabel.text = website.websitePassword
            website.username = activeUser
        }
    }


    
    
    @IBAction func btnUpdate(_ sender: Any) {
        guard let selectedWebsite = selectedWebsite else {
            return
        }
        selectedWebsite.websiteName = websiteNameLabel.text
        selectedWebsite.websiteURL = websiteURLLabel.text
        selectedWebsite.websiteUsername = websiteUsernameLabel.text
        selectedWebsite.websitePassword = websitePasswordLabel.text
        selectedWebsite.username = activeUser

        do {
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            try context.save()
        } catch {
            // Handle save errors, e.g., show an alert or log the error
            //print("Error saving data: \(error)")
        }

        // Disable editing after updating
        websiteNameLabel.isEnabled = false
        websiteURLLabel.isEditable = false
        websiteUsernameLabel.isEnabled = false
        websitePasswordLabel.isEnabled = false
    }
    
    

    
}
