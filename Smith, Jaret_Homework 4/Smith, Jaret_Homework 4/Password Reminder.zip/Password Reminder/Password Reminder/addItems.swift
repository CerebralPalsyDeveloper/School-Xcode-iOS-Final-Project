//
//  addItems.swift
//  Password Reminder
//
//  Created by Jaret Smith on 10/28/23.
//

import UIKit
import CoreData

class addItems: UIViewController {
    
    @IBOutlet weak var tfWebsiteTitle: UITextField!
    
    @IBOutlet weak var tfWebsiteURL: UITextField!
    
    @IBOutlet weak var tfWebsiteUsername: UITextField!
    
    @IBOutlet weak var tfWebsitePassword: UITextField!
    
    @IBOutlet weak var btnSaveItem: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    @IBAction func btnSave(_ sender: Any) {
        let newTask = Websites(context: context)
        newTask.username = activeUser
        
        // Check for empty fields
        if let websiteTitle = tfWebsiteTitle.text, !websiteTitle.isEmpty,
           let websiteURL = tfWebsiteURL.text, !websiteURL.isEmpty,
           let websiteUsername = tfWebsiteUsername.text, !websiteUsername.isEmpty,
           let websitePassword = tfWebsitePassword.text, !websitePassword.isEmpty {
            
            // If all fields are filled, save the data and perform the unwind segue
            newTask.websiteName = websiteTitle
            newTask.websiteURL = websiteURL
            newTask.websiteUsername = websiteUsername
            newTask.websitePassword = websitePassword
            
            appDelegate.saveContext()
            
            // Clear the text fields
            tfWebsiteTitle.text = ""
            tfWebsiteURL.text = ""
            tfWebsiteUsername.text = ""
            tfWebsitePassword.text = ""
        }
        else {
            // Show an alert if any fields are empty
            showAlert(title: "Missing Information", message: "Please fill in all fields.")
        }
    }
        
        func showAlert(title: String, message: String) {
            let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(okAction)
            present(alertController, animated: true, completion: nil)
        }
        
        
        func generateRandomPassword(length: Int) -> String {
            let characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+[]{}|:;<>,.?/~"
            let password = String((0..<length).map { _ in characters.randomElement()! })
            return password
        }
    
    @IBAction func generatePasswordButtonTapped(_ sender: Any) {
        let generatedPassword = generateRandomPassword(length: 12) // You can adjust the length as needed
            tfWebsitePassword.text = generatedPassword
    }
    
}
