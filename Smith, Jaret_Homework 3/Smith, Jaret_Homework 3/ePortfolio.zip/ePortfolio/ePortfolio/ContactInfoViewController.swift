//
//  ContactInfoViewController.swift
//  ePortfolio
//
//  Created by Jaret Smith on 10/15/23.
//

import UIKit

class ContactInfoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    //exceeding expectations feature
    @IBAction func openWebsite(_ sender: Any) {
        if let url = URL(string: "https://github.com/CerebralPalsyDeveloper")
        {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
    
}
