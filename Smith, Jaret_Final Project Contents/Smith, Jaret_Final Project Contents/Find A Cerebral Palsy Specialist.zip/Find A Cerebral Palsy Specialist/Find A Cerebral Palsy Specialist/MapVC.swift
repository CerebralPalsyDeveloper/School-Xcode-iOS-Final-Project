//
//  MapVC.swift
//  Find A Cerebral Palsy Specialist
//
//  Created by Jaret Smith on 11/20/23.
//

import UIKit
import MapKit
import CoreLocation


class MapVC: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    var appointmentTimes: [String: [String]] = [:]
    //var appointmentStatus: [Bool] = []
    // Add a variable to store the selected location and appointment time
    var selectedLocationTitle: String?
    var selectedAppointmentTime: String?
    
    func didUpdateAppointmentStatus(_ appointmentStatus: [Bool]) {
            // Update the appointment status in MapVC
            //self.appointmentStatus = appointmentStatus
        
        // Print the updated appointment status
            print("Updated Appointment Status in MapVC: \(appointmentStatus)")
        
        }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //didUpdateAppointmentStatus(appointmentStatus)
        
        
        // Do any additional setup after loading the view.
        
        // Appointment times should have true or false
        
        appointmentTimes["California Pacific Medical"] = ["California Pacific Medical - Monday, 9:00 AM", "California Pacific Medical - Tuesday, 2:00 PM", "California Pacific Medical - Thursday, 4:00 PM"]
        appointmentTimes["UCSF Pediatric Cerebral Palsy"] = ["UCSF Pediatric Cerebral Palsy - Wednesday, 10:30 AM", "UCSF Pediatric Cerebral Palsy - Wednesday, 1:30 PM", "UCSF Pediatric Cerebral Palsy - Friday, 3:00 PM"]
        appointmentTimes["Cerebral Palsy Center for the Bay Area, Inc."] = ["Cerebral Palsy Center for the Bay Area, Inc. - Monday, 8:00 AM", "Cerebral Palsy Center for the Bay Area, Inc. - Thursday, 11:00 AM", "Cerebral Palsy Center for the Bay Area, Inc. - Friday, 4:00 PM"]
        
        //appointmentStatus = initializeAppointmentStatusIfNeeded()
        
        let sp1 = MKPointAnnotation()
        sp1.coordinate = CLLocationCoordinate2DMake(37.786380, -122.456250)
        sp1.title = "California Pacific Medical"
        
        let sp2 = MKPointAnnotation()
        sp2.coordinate = CLLocationCoordinate2DMake(37.766630, -122.390310)
        sp2.title = "UCSF Pediatric Cerebral Palsy"
        
        let sp3 = MKPointAnnotation()
        sp3.coordinate = CLLocationCoordinate2DMake(37.808620, -122.201770)
        sp3.title = "Cerebral Palsy Center for the Bay Area, Inc."
        
        mapLocation.addAnnotations([sp1, sp2, sp3])
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
        mapLocation.delegate = self
    }
    
    var locationManager = CLLocationManager()
    @IBOutlet weak var mapLocation: MKMapView!
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let userLocation:CLLocation = locations[0]
        
        locationManager.stopUpdatingLocation()
        
        let here = MKPointAnnotation()
        here.coordinate = CLLocationCoordinate2DMake(userLocation.coordinate.latitude, userLocation.coordinate.longitude)
        here.title = "Hello I am here"
        
        mapLocation.addAnnotation(here)
        let region = MKCoordinateRegion(center: userLocation.coordinate, latitudinalMeters: 10000, longitudinalMeters: 10000)
        
        mapLocation.setRegion(region, animated: true)
        
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        if let annotation = view.annotation as? MKPointAnnotation {
            // Check if the selected annotation is the "Hello I am here" annotation
            if annotation.title != "Hello I am here" {
                // Perform the segue to AppointmentsVC with the selected annotation information
                performSegue(withIdentifier: "toAppointmentsVC", sender: annotation)
            }
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toAppointmentsVC", let appointmentsVC = segue.destination as? AppointmentsVC,
            let selectedAnnotation = sender as? MKPointAnnotation {
                // Pass the necessary information to AppointmentsVC
                appointmentsVC.selectedLocationTitle = selectedAnnotation.title
                appointmentsVC.appointmentTimes = appointmentTimes  // Pass the appointment times dictionary
                //appointmentsVC.appointmentStatus = appointmentStatus // Pass the appointment status array
        }
    }
    
}
