//
//  UserProfileVC.swift
//  Find A Cerebral Palsy Specialist
//
//  Created by Jaret Smith on 11/17/23.
//


import UIKit
import CoreData

class UserProfileVC: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, ConfirmAppointmentDelegate {

    var email: String?
    var password: String?
    var name: String?
    var selectedImage: UIImage?  // To store the selected image
    var isTaken: Bool = false

    override func viewDidLoad() {
        super.viewDidLoad()

        loadUserData()

        lblUsername.text = email
        lblPassword.text = password
        lblName.text = name
        imgPicture.image = selectedImage
        
        if let appointmentTime = getAppointmentTimeForUser() {
            didSelectAppointmentTime(appointmentTime)
        }
    }
    
    func getAppointmentTimeForUser() -> String? {
        guard let activeUserEmail = activeUser else {
            return nil
        }

        let fetchRequest: NSFetchRequest<Accounts> = Accounts.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "email == %@", activeUserEmail)

        do {
            let matchingAccounts = try context.fetch(fetchRequest)
            if let userAccount = matchingAccounts.first {
                return userAccount.appointmentAttribute
            }
        } catch {
            print("Error fetching appointment time: \(error.localizedDescription)")
        }

        return nil
    }

    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet weak var lblPassword: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgPicture: UIImageView!
    @IBOutlet weak var btnSaveAction: UIButton!
    @IBOutlet weak var lblAppointment: UILabel!
    
    func loadUserData() {
        guard let activeUserEmail = activeUser else {
            return
        }

        let fetchRequest: NSFetchRequest<Accounts> = Accounts.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "email == %@", activeUserEmail)

        do {
            let existingAccounts = try context.fetch(fetchRequest)
            for userAccount in existingAccounts {
                // Update the properties only if the email matches
                if let email = userAccount.email, email == activeUserEmail {
                    self.email = email
                    self.password = userAccount.password
                    self.name = userAccount.name

                    // Load appointmentAttribute if it exists
                    if let appointmentAttribute = userAccount.appointmentAttribute {
                        // Do something with the appointmentAttribute
                        // For example, update a label or property in your view controller
                        print("Loaded appointmentAttribute: \(appointmentAttribute)")
                    }

                    // Load isTaken attribute if it exists
                    self.isTaken = userAccount.isTaken

                    // Assuming 'imageAttribute' is a Binary Data attribute in the Accounts entity
                    if let imageData = userAccount.imageAttribute {
                        self.selectedImage = UIImage(data: imageData)
                        imgPicture.image = selectedImage
                    }
                }
            }
        } catch {
            print("Error loading user data: \(error.localizedDescription)")
        }
    }

    @IBAction func btnAddProfilePic(_ sender: Any) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = .photoLibrary
        present(imagePickerController, animated: true, completion: nil)
    }

    @IBAction func btnTakePicture(_ sender: Any) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        
        // Check if the camera is available
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            
            // Check if the front camera is available
            if UIImagePickerController.isCameraDeviceAvailable(.front) {
                imagePicker.cameraDevice = .front
            } else {
                imagePicker.cameraDevice = .rear
            }
        } else {
            imagePicker.sourceType = .photoLibrary
        }
        
        present(imagePicker, animated: true, completion: nil)
    }


    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            selectedImage = pickedImage
            imgPicture.image = pickedImage
        }

        self.dismiss(animated: true, completion: nil)
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }

    func saveImageToCoreData() {
        guard let email = email, let pickedImage = selectedImage else {
            return
        }

        let fetchRequest: NSFetchRequest<Accounts> = Accounts.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "email == %@", email)

        do {
            let existingAccounts = try context.fetch(fetchRequest)
            if let userAccount = existingAccounts.first {
                // Convert UIImage to Data
                if let imageData = pickedImage.jpegData(compressionQuality: 1.0) {
                    // Assign the image data to the 'imageAttribute'
                    userAccount.imageAttribute = imageData
                    appDelegate.saveContext()
                }
            }
        } catch {
            print("Error saving image to Core Data: \(error.localizedDescription)")
        }
    }

    @IBAction func btnSave(_ sender: Any) {
        saveImageToCoreData()
    }

    @IBAction func btnSignOut(_ sender: Any) {
        activeUser = nil
    }
    
    func didSelectAppointmentTime(_ appointmentTime: String) {
        print("Appointment Time: \(appointmentTime)")
        lblAppointment.text = appointmentTime
        }
    // Inside the UserProfileVC where you present ConfirmAppointmentVC
    // Inside UserProfileVC
    func presentConfirmAppointmentVC() {
        // Assuming ConfirmAppointmentVC is the storyboard identifier for your ConfirmAppointmentVC
        if let confirmVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ConfirmAppointmentVC") as? ConfirmAppointmentVC {
            confirmVC.delegate = self
            present(confirmVC, animated: true, completion: nil)
        }
    }
}



