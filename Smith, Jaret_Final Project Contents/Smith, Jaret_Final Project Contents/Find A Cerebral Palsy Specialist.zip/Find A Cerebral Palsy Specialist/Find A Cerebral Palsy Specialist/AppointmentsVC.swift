//
//  AppointmentsVC.swift
//  Find A Cerebral Palsy Specialist
//
//  Created by Jaret Smith on 11/20/23.
//

import UIKit
import CoreData

// Define a protocol for the delegate
protocol AppointmentsDelegate: AnyObject {
    func didSelectAppointmentTime(_ appointmentTime: String)
}


class AppointmentsVC: UIViewController, UITableViewDataSource, UITableViewDelegate, ConfirmAppointmentDelegate {
    
    func didSelectAppointmentTime(_ appointmentTime: String) {
        if let selectedIndex = selectedAppointmentTimes.firstIndex(of: appointmentTime) {
            // Update the status of the selected appointment to "Taken"
            // appointmentStatus[selectedIndex] = false

            // Reload the specific table view cell to reflect the updated status
            DispatchQueue.main.async {
                if let cell = self.tblAppointments.cellForRow(at: IndexPath(row: selectedIndex, section: 0)) {
                    cell.textLabel?.text = "Taken"
                    cell.isUserInteractionEnabled = false
                    print("Reloaded cell at index \(selectedIndex). isUserInteractionEnabled set to \(cell.isUserInteractionEnabled)")
                    print("Updated appointmentStatus at index \(selectedIndex) to false")
                    //print("Appointment Time: \(appointmentTime), Is Available: \(self.appointmentStatus[selectedIndex])")
                } else {
                    print("Failed to reload cell at index \(selectedIndex).")
                }
            }
        }
    }
    

    @IBOutlet weak var tblAppointments: UITableView!

    var selectedLocationTitle: String?
    var appointmentTimes: [String: [String]] = [:]
    var selectedAppointmentTimes: [String] = []
    
    var selectedAppointmentIndex: Int?
    
    var appointmentStatus: [Bool] = []

    // Add the delegate property
    weak var delegate: AppointmentsDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()

        tblAppointments.register(UITableViewCell.self, forCellReuseIdentifier: "appointmentCell")

        if let title = selectedLocationTitle {
            selectedAppointmentTimes = appointmentTimes[title] ?? []
            tblAppointments.reloadData()
        }
    }


    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return selectedAppointmentTimes.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "appointmentCell", for: indexPath)

        let appointmentTime = selectedAppointmentTimes[indexPath.row]

        // Fetch the CoreData record corresponding to the selected appointment time
        let fetchRequest: NSFetchRequest<Accounts> = Accounts.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "appointmentAttribute == %@", appointmentTime)

        do {
            let matchingAccounts = try context.fetch(fetchRequest)
            if let firstMatchingAccount = matchingAccounts.first {
                // Check if the appointment is taken
                if firstMatchingAccount.isTaken {
                    // If taken, show "Taken" as text and disable user interaction
                    cell.textLabel?.text = "Taken"
                    cell.isUserInteractionEnabled = false
                } else {
                    // If available, show the appointment time as text and enable user interaction
                    cell.textLabel?.text = appointmentTime
                    cell.textLabel?.numberOfLines = 0
                    cell.textLabel?.lineBreakMode = .byWordWrapping
                    cell.isUserInteractionEnabled = true
                }
            } else {
                // Handle the case where no matching account is found
                print("No matching account found for \(appointmentTime)")
                // Show the appointment time as text and enable user interaction by default
                cell.textLabel?.text = appointmentTime
                cell.textLabel?.numberOfLines = 0
                cell.textLabel?.lineBreakMode = .byWordWrapping
                cell.isUserInteractionEnabled = true
            }
        } catch {
            print("Error fetching account data: \(error.localizedDescription)")
            // Show the appointment time as text and enable user interaction by default
            cell.textLabel?.text = appointmentTime
            cell.textLabel?.numberOfLines = 0
            cell.textLabel?.lineBreakMode = .byWordWrapping
            cell.isUserInteractionEnabled = true
        }

        return cell
    }


    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Get the selected appointment time
        let selectedAppointmentTime = selectedAppointmentTimes[indexPath.row]

        // Call the delegate method
        delegate?.didSelectAppointmentTime(selectedAppointmentTime)

        // Set the selectedAppointmentIndex
        selectedAppointmentIndex = indexPath.row
        
        print("Selected Index: \(selectedAppointmentIndex ?? -1)")
        print("Selected Appointment Time: \(selectedAppointmentTime)")

        // Update the status of the selected appointment to "Taken"
        //if let selectedIndex = selectedAppointmentIndex {
            //appointmentStatus[selectedIndex] = false
        //}

        // Perform the segue to ConfirmAppointmentsVC when a cell is tapped
        performSegue(withIdentifier: "toConfirmAppointmentVC", sender: nil)
    }



    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toConfirmAppointmentVC", let confirmAppointmentVC = segue.destination as? ConfirmAppointmentVC,
            let selectedIndex = tblAppointments.indexPathForSelectedRow?.row {
            print("Passing Selected Index to ConfirmAppointmentVC: \(selectedIndex)")
            // Pass the necessary information to ConfirmAppointmentVC
            confirmAppointmentVC.selectedAppointmentIndex = selectedIndex
            confirmAppointmentVC.delegate = self
            confirmAppointmentVC.selectedAppointmentTime = selectedAppointmentTimes[selectedIndex]
            confirmAppointmentVC.appointmentStatus = appointmentStatus
            //confirmAppointmentVC.locationTitle = selectedLocationTitle
        }
    }

}


