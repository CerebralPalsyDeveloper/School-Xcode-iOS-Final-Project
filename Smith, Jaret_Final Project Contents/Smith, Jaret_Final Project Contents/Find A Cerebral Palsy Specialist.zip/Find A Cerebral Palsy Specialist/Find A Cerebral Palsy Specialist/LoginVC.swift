//
//  ViewController.swift
//  Find A Cerebral Palsy Specialist
//
//  Created by Jaret Smith on 11/17/23.
//

import UIKit
import CoreData

let appDelegate = UIApplication.shared.delegate as! AppDelegate
let context = appDelegate.persistentContainer.viewContext

var activeUser: String?

class LoginVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtName: UITextField!

    func addNewAccount(newAccountEmail: String, newAccountPassword: String, newAccountName: String) {
        let newAccount = Accounts(context: context)

        // Set account properties
        newAccount.email = newAccountEmail
        newAccount.password = newAccountPassword
        newAccount.name = newAccountName

        // Save the context after setting properties
        appDelegate.saveContext()
    }
    
    
    func isValidEmail(_ email: String) -> Bool {
        // Define a regular expression pattern for a simple email validation
        let emailRegex = #"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"#
        
        // Create a regular expression object
        guard let regex = try? NSRegularExpression(pattern: emailRegex) else {
            return false
        }
        
        // Match the email against the regular expression
        let matches = regex.matches(in: email, range: NSRange(email.startIndex..., in: email))
        
        // If there is at least one match, the email is valid
        return !matches.isEmpty
    }

    @IBAction func btnRegisterUser(_ sender: Any) {
        let newEmail = txtEmail.text
        let newPassword = txtPassword.text
        let newName = txtName.text

        if let email = newEmail, let password = newPassword, let name = newName {
            // Check if the email has a valid format
            if isValidEmail(email) {
                // Check if the email already exists
                if emailExists(email: email) {
                    // Email already exists, show an alert
                    showAlert(title: "Email Exists", message: "The email is already in use. Please choose a different email.")
                } else {
                    // Email is unique, proceed to create and save the new account
                    addNewAccount(newAccountEmail: email, newAccountPassword: password, newAccountName: name)
                    showAlert(title: "Registration Successful", message: "The registration is successful")
                }
            } else {
                // Invalid email format, show an alert
                showAlert(title: "Invalid Email", message: "Please enter a valid email address.")
            }
        }
    }


    func showAlert(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }

    func emailExists(email: String?) -> Bool {
        if let email = email {
            let fetchRequest: NSFetchRequest<Accounts> = Accounts.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "email == %@", email)

            do {
                let existingAccounts = try context.fetch(fetchRequest)
                return !existingAccounts.isEmpty
            } catch {
                //print("Error checking email existence: \(error.localizedDescription)")
                return false
            }
        }
        return false
    }

    @IBAction func btnSignIn(_ sender: Any) {
        var data = [Accounts]()

        do {
            data = try context.fetch(Accounts.fetchRequest())

            for existingAccount in data {
                if existingAccount.email == txtEmail.text && existingAccount.password == txtPassword.text {
                    // Sign-in successful logic
                    activeUser = txtEmail.text
                    performSegue(withIdentifier: "toUserProfileVC", sender: nil)
                    return
                }
            }


            // If no match was found, show an alert for sign-in failure
            showAlert(title: "Error", message: "Invalid credentials. Please try again.")
        } catch {
            // Handle fetch request errors
            //print("Error during sign-in: \(error.localizedDescription)")
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toUserProfileVC" {
            if let userProfileVC = segue.destination as? UserProfileVC {
                // Pass the email, password, and name to UserProfileVC
                userProfileVC.email = txtEmail.text
                userProfileVC.password = txtPassword.text
                userProfileVC.name = txtName.text
            }
        }
    }
}
