//
//  ConfirmAppointmentVC.swift
//  Find A Cerebral Palsy Specialist
//
//  Created by Jaret Smith on 11/20/23.
//
import UIKit
import CoreData
//import MapKit

protocol ConfirmAppointmentDelegate: AnyObject {
    func didSelectAppointmentTime(_ appointmentTime: String)
}
/*protocol AppointmentStatusDelegate: AnyObject {
    func didUpdateAppointmentStatus(_ appointmentStatus: [Bool])
} */

// ConfirmAppointmentVC
class ConfirmAppointmentVC: UIViewController {
    
    weak var delegate: ConfirmAppointmentDelegate?
    //weak var appointmentStatusDelegate: AppointmentStatusDelegate?


    var selectedAppointmentTime: String?
    var selectedAppointmentIndex: Int?
    //var selectedAppointmentLocation: MKPointAnnotation?
    
    var appointment: String?
    
    var appointmentStatus: [Bool] = []  // Initialize this array based on your data
    
    
    @IBAction func btnYes(_ sender: Any) {
        guard let appointmentAttribute = selectedAppointmentTime
              //let selectedIndex = selectedAppointmentIndex
        else {
            return
        }

        // Save the selected appointment attribute to CoreData
        saveAppointmentToCoreData(appointmentAttribute: appointmentAttribute, isTaken: true)

        // Notify the delegate about the selected appointment time
        delegate?.didSelectAppointmentTime(appointmentAttribute)

        // Perform actions when the user clicks "Yes"
        self.navigationController?.popViewController(animated: true)
    }


    
    func saveAppointmentToCoreData(appointmentAttribute: String, isTaken: Bool) {
        guard let activeUserEmail = activeUser else {
            return
        }

        let fetchRequest: NSFetchRequest<Accounts> = Accounts.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "email == %@", activeUserEmail)

        do {
            let matchingAccounts = try context.fetch(fetchRequest)
            for userAccount in matchingAccounts {
                // Update the 'appointmentAttribute' and 'isTaken' attributes
                userAccount.appointmentAttribute = appointmentAttribute
                userAccount.isTaken = isTaken
            }

            // Save the context after updating all matching accounts
            appDelegate.saveContext()
        } catch {
            print("Error saving appointment to Core Data: \(error.localizedDescription)")
        }
    }


}
