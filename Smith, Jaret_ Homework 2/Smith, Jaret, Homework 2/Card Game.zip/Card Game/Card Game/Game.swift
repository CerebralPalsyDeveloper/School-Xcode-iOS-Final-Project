//
//  Game.swift
//  Card Game
//
//  Created by Jaret Smith on 9/26/23.
//

import UIKit

class Game: UIViewController {
    @IBOutlet weak var lblPlayer1: UILabel!
    @IBOutlet weak var lblPlayer2: UILabel!
    
    
    @IBOutlet weak var cardbtn1: UIButton!
    @IBOutlet weak var cardbtn2: UIButton!
    @IBOutlet weak var cardbtn3: UIButton!
    
    @IBOutlet weak var cardbtn4: UIButton!
    @IBOutlet weak var cardbtn5: UIButton!
    @IBOutlet weak var cardbtn6: UIButton!
    
    @IBOutlet weak var cardbtn7: UIButton!
    @IBOutlet weak var cardbtn8: UIButton!
    @IBOutlet weak var cardbtn9: UIButton!
    
    @IBOutlet weak var cardbtn10: UIButton!
    @IBOutlet weak var cardbtn11: UIButton!
    @IBOutlet weak var cardbtn12: UIButton!
    //card images
    var cards = [
        "image1",
        "image2",
        "image3",
        "image4",
        "image5",
        "image6",
        "image1",
        "image2",
        "image3",
        "image4",
        "image5",
        "image6"
    ]
    
    var buttons = [UIButton]()
    
    var click = 1
    
    var click1 = 0
    var click2 = 0
    
    var points1 = 0
    var points2 = 0
    
    var player = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //shuffle the cards
        cards.shuffle()
        
        lblPlayer2.textColor = .gray
        
        //add buttons to an array
        buttons.append(cardbtn1)
        buttons.append(cardbtn2)
        buttons.append(cardbtn3)
        buttons.append(cardbtn4)
        buttons.append(cardbtn5)
        buttons.append(cardbtn6)
        buttons.append(cardbtn7)
        buttons.append(cardbtn8)
        buttons.append(cardbtn9)
        buttons.append(cardbtn10)
        buttons.append(cardbtn11)
        buttons.append(cardbtn12)
        
    }

    @IBAction func btnReset(_ sender: Any) {
        player = 1
        lblPlayer1.textColor = .black
        lblPlayer2.textColor = .gray
        points1 = 0
        points2 = 0
        click = 1
        click1 = 0
        click2 = 0
        lblPlayer1.text = "Player 1: \(points1)"
        lblPlayer2.text = "Player 2: \(points2)"
        cards = [
            "image1",
            "image2",
            "image3",
            "image4",
            "image5",
            "image6",
            "image1",
            "image2",
            "image3",
            "image4",
            "image5",
            "image6"
        ]
        cards.shuffle()
        
        //add buttons to an array
        buttons.append(cardbtn1)
        buttons.append(cardbtn2)
        buttons.append(cardbtn3)
        buttons.append(cardbtn4)
        buttons.append(cardbtn5)
        buttons.append(cardbtn6)
        buttons.append(cardbtn7)
        buttons.append(cardbtn8)
        buttons.append(cardbtn9)
        buttons.append(cardbtn10)
        buttons.append(cardbtn11)
        buttons.append(cardbtn12)
        
        for i in buttons {
            i.setImage(UIImage(named: "image7"), for: .normal)
        }
        for i in buttons{
            i.alpha = 1.0
        }
        
        
        
    }
    
    
    @IBAction func cardbtn1Action(_ sender: Any)
    {
        
        if click == 1
        {
            cardbtn1.setImage(UIImage(named: cards[0]), for: .normal)
            click = 2
            click1 = 1
        }
        else if click == 2
        {
            cardbtn1.setImage(UIImage(named: cards[0]), for: .normal)
                click = 1
                click2 = 1
                
                compare()
            }
        }
    
    @IBAction func cardbtn2Action(_ sender: Any) {
        if click == 1
        {
            cardbtn2.setImage(UIImage(named: cards[1]), for: .normal)
            click = 2
            click1 = 2
        }
        else if click == 2 {
            cardbtn2.setImage(UIImage(named: cards[1]), for: .normal)
            click = 1
            click2 = 2
            
            compare()
        }
    }
    @IBAction func cardbtn3Action(_ sender: Any) {
        if click == 1 {
            cardbtn3.setImage(UIImage(named: cards[2]), for: .normal)
            click = 2
            click1 = 3
        }
        else if click == 2
        {
            cardbtn3.setImage(UIImage(named: cards[2]), for: .normal)
            click = 1
            click2 = 3
            
            compare()
        }
    }
    
    
    @IBAction func cardbtn4Action(_ sender: Any) {
        if click == 1 {
            cardbtn4.setImage(UIImage(named: cards[3]), for: .normal)
            click = 2
            click1 = 4
        } else if click == 2 {
            cardbtn4.setImage(UIImage(named: cards[3]), for: .normal)
            click = 1
            click2 = 4
            
            compare()
        }
    }
    @IBAction func cardbtn5Action(_ sender: Any) {
        if click == 1 {
            cardbtn5.setImage(UIImage(named: cards[4]), for: .normal)
            click = 2
            click1 = 5
        } else if click == 2 {
            cardbtn5.setImage(UIImage(named: cards[4]), for: .normal)
            click = 1
            click2 = 5
            
            compare()
        }
    }
    @IBAction func cardbtn6Action(_ sender: Any) {
        if click == 1 {
            cardbtn6.setImage(UIImage(named: cards[5]), for: .normal)
            click = 2
            click1 = 6
        } else if click == 2 {
            cardbtn6.setImage(UIImage(named: cards[5]), for: .normal)
            click = 1
            click2 = 6
            
            compare()
        }
    }
    
    
    @IBAction func cardbtn7Action(_ sender: Any) {
        if click == 1 {
            cardbtn7.setImage(UIImage(named: cards[6]), for: .normal)
            click = 2
            click1 = 7
        } else if click == 2 {
            cardbtn7.setImage(UIImage(named: cards[6]), for: .normal)
            click = 1
            click2 = 7
            
            compare()
        }
    }
    @IBAction func cardbtn8Action(_ sender: Any) {
        if click == 1 {
            cardbtn8.setImage(UIImage(named: cards[7]), for: .normal)
            click = 2
            click1 = 8
        } else if click == 2 {
            cardbtn8.setImage(UIImage(named: cards[7]), for: .normal)
            click = 1
            click2 = 8
            
            compare()
        }
    }
    @IBAction func cardbtn9Action(_ sender: Any) {
        if click == 1 {
            cardbtn9.setImage(UIImage(named: cards[8]), for: .normal)
            click = 2
            click1 = 9
        }
        else if click == 2 {
            cardbtn9.setImage(UIImage(named: cards[8]), for: .normal)
            click = 1
            click2 = 9
            
            compare()
        }
    }
    
    
    @IBAction func cardbtn10Action(_ sender: Any) {
        if click == 1
        {
            cardbtn10.setImage(UIImage(named: cards[9]), for: .normal)
            click = 2
            click1 = 10
        }
        else if click == 2
        {
            cardbtn10.setImage(UIImage(named: cards[9]), for: .normal)
            click = 1
            click2 = 10
            
            compare()
        }
    }
    @IBAction func cardbtn11Action(_ sender: Any) {
        if click == 1
        {
            cardbtn11.setImage(UIImage(named: cards[10]), for: .normal)
            click = 2
            click1 = 11
        } else if click == 2
        {
            cardbtn11.setImage(UIImage(named: cards[10]), for: .normal)
            click = 1
            click2 = 11
            
            compare()
        }
    }
    @IBAction func cardbtn12Action(_ sender: Any) {
        if click == 1 {
            cardbtn12.setImage(UIImage(named: cards[11]), for: .normal)
            click = 2
            click1 = 12
        } else if click == 2 {
            cardbtn12.setImage(UIImage(named: cards[11]), for: .normal)
            click = 1
            click2 = 12
            
            compare()
        }
    }
    
    func compare() {
        if cards[click1-1] == cards[click2-1] {
            //same images
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
                //hide images
                self.buttons[self.click1-1].alpha = 0
                self.buttons[self.click2-1].alpha = 0
                
                if self.player == 1
                {
                    self.points1 = self.points1 + 1
                    self.lblPlayer1.text = "Player 1: \(self.points1)"
                }
                else if self.player == 2 {
                    self.points2 = self.points2 + 1
                    self.lblPlayer2.text = "Player 2: \(self.points2)"
                }
                
            }
        }
        else
        {
            //different images
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1)
            {
                //hide images
                self.buttons[self.click1-1].setImage(UIImage(named: "image7"), for: .normal)
                self.buttons[self.click2-1].setImage(UIImage(named: "image7"), for: .normal)
                
                self.switchPlayer()
            }
        }
    }
    
    func switchPlayer() {
        //switch player
        if player == 1
        {
            player = 2
            
            lblPlayer1.textColor = .gray
            lblPlayer2.textColor = .black
        }
        else
        {
            player = 1
            
            lblPlayer1.textColor = .black
            lblPlayer2.textColor = .gray
        }
    }
}
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
