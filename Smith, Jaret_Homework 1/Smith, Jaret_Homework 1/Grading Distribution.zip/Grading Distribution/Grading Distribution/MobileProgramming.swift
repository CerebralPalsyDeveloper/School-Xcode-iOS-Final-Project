//
//  MobileProgramming.swift
//  Grading Distribution
//
//  Created by Jaret Smith on 9/15/23.
//

import UIKit

class MobileProgramming: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var mpResultLabel: UILabel!
    @IBOutlet weak var mpLetterLabel: UILabel!
    
    @IBOutlet weak var gradeImg: UIImageView!
    
    
    func calculateGrade() {
        let value1 = Int(mpSliderValue1.value * 60)
        let value2 = Int(mpSliderValue2.value * 15)
        let value3 = Int(mpSliderValue3.value * 25)
        
        let sum = value1 + value2 + value3
        
        mpResultLabel.text = "\(sum)"
        
        if sum >= 90
        {
            mpLetterLabel.text = "A"
            gradeImg.isHidden = false
        }
        else if sum >= 80 && sum < 90
        {
            mpLetterLabel.text = "B"
            gradeImg.isHidden = true
        }
        else if sum >= 70 && sum < 80
        {
            mpLetterLabel.text = "C"
            gradeImg.isHidden = true
        }
        else if sum >= 60 && sum < 70
        {
            mpLetterLabel.text = "D"
            gradeImg.isHidden = true
        }
        else
        {
            mpLetterLabel.text = "F"
            gradeImg.isHidden = true
        }
    }
    
    
    @IBOutlet weak var mpSliderValue1: UISlider!
    
    @IBOutlet weak var mpSliderLabel1: UILabel!
    
    @IBAction func mpSliderControl1(_ sender: UISlider)
    {
        mpSliderLabel1.text = "\(Int(mpSliderValue1.value * 60))"
        
        calculateGrade()
        
    }
    
    @IBOutlet weak var mpSliderValue2: UISlider!
    
    @IBOutlet weak var mpSliderLabel2: UILabel!
    
    @IBAction func mpSliderControl2(_ sender: UISlider)
    {
        mpSliderLabel2.text = "\(Int(mpSliderValue2.value * 15))"
        
        calculateGrade()
        
    }
    
    @IBOutlet weak var mpSliderValue3: UISlider!
    
    @IBOutlet weak var mpSliderLabel3: UILabel!
    
    @IBAction func mpSliderControl3(_ sender: UISlider)
    {
        mpSliderLabel3.text = "\(Int(mpSliderValue3.value * 25))"
        
        calculateGrade()
        
    }
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
