//
//  Operating Systems.swift
//  Grading Distribution
//
//  Created by Jaret Smith on 9/15/23.
//

import UIKit

class Operating_Systems: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var osResultLabel: UILabel!
    @IBOutlet weak var osLetterLabel: UILabel!
    
    @IBOutlet weak var gradeImg: UIImageView!
    
    
    func calculateGrade() {
        let value1 = Int(osSliderValue1.value * 45)
        let value2 = Int(osSliderValue2.value * 25)
        let value3 = Int(osSliderValue3.value * 30)
        
        let sum = value1 + value2 + value3
        
        osResultLabel.text = "\(sum)"
        
        if sum >= 90
        {
            osLetterLabel.text = "A"
            gradeImg.isHidden = false
        }
        else if sum >= 80 && sum < 90
        {
            osLetterLabel.text = "B"
            gradeImg.isHidden = true
        }
        else if sum >= 70 && sum < 80
        {
            osLetterLabel.text = "C"
            gradeImg.isHidden = true
        }
        else if sum >= 60 && sum < 70
        {
            osLetterLabel.text = "D"
            gradeImg.isHidden = true
        }
        else
        {
            osLetterLabel.text = "F"
            gradeImg.isHidden = true
        }
    }
    
    
    @IBOutlet weak var osSliderValue1: UISlider!
    
    @IBOutlet weak var osSliderLabel1: UILabel!
    
    @IBAction func osSliderControl1(_ sender: UISlider)
    {
        osSliderLabel1.text = "\(Int(osSliderValue1.value * 45))"
        
        calculateGrade()
        
    }
    
    @IBOutlet weak var osSliderValue2: UISlider!
    
    @IBOutlet weak var osSliderLabel2: UILabel!
    
    @IBAction func osSliderControl2(_ sender: UISlider)
    {
        osSliderLabel2.text = "\(Int(osSliderValue2.value * 25))"
        
        calculateGrade()
        
    }
    
    @IBOutlet weak var osSliderValue3: UISlider!
    
    @IBOutlet weak var osSliderLabel3: UILabel!
    
    @IBAction func osSliderControl3(_ sender: UISlider)
    {
        osSliderLabel3.text = "\(Int(osSliderValue3.value * 30))"
        
        calculateGrade()
        
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
