//
//  DifferentialEquations.swift
//  Grading Distribution
//
//  Created by Jaret Smith on 9/15/23.
//

import UIKit

class DifferentialEquations: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var deResultLabel: UILabel!
    @IBOutlet weak var deLetterLabel: UILabel!
    @IBOutlet weak var gradeImg: UIImageView!
    
    func calculateGrade() {
        let value1 = Int(deSliderValue1.value * 25)
        let value2 = Int(deSliderValue2.value * 50)
        let value3 = Int(deSliderValue3.value * 25)
        
        let sum = value1 + value2 + value3
        
        deResultLabel.text = "\(sum)"
        
        if sum >= 90
        {
            deLetterLabel.text = "A"
            gradeImg.isHidden = false
        }
        else if sum >= 80 && sum < 90
        {
            deLetterLabel.text = "B"
            gradeImg.isHidden = true
        }
        else if sum >= 70 && sum < 80
        {
            deLetterLabel.text = "C"
            gradeImg.isHidden = true
        }
        else if sum >= 60 && sum < 70
        {
            deLetterLabel.text = "D"
            gradeImg.isHidden = true
        }
        else
        {
            deLetterLabel.text = "F"
            gradeImg.isHidden = true
        }
    }
    
    
    @IBOutlet weak var deSliderValue1: UISlider!
    
    @IBOutlet weak var deSliderLabel1: UILabel!
    
    @IBAction func deSliderControl1(_ sender: UISlider)
    {
        deSliderLabel1.text = "\(Int(deSliderValue1.value * 25))"
        
        calculateGrade()
        
    }
    
    @IBOutlet weak var deSliderValue2: UISlider!
    
    @IBOutlet weak var deSliderLabel2: UILabel!
    
    @IBAction func deSliderControl2(_ sender: UISlider)
    {
        deSliderLabel2.text = "\(Int(deSliderValue2.value * 50))"
        
        calculateGrade()
        
    }
    
    @IBOutlet weak var deSliderValue3: UISlider!
    
    @IBOutlet weak var deSliderLabel3: UILabel!
    
    @IBAction func deSliderControl3(_ sender: UISlider)
    {
        deSliderLabel3.text = "\(Int(deSliderValue3.value * 25))"
        
        calculateGrade()
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
