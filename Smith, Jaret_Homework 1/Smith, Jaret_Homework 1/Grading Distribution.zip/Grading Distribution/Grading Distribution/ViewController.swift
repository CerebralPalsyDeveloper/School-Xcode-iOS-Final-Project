//
//  ViewController.swift
//  Grading Distribution
//
//  Created by Jaret Smith on 9/14/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

